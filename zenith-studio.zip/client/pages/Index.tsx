import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Activity,
  BarChart3,
  CheckCircle2,
  Copy,
  Link2,
  LockKeyhole,
  Power,
  RefreshCw,
  Rocket,
  Shield,
  ShieldCheck,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";

export default function Index() {
  const [botOnline, setBotOnline] = useState(true);
  const [tokenCopied, setTokenCopied] = useState(false);
  const [apiToken, setApiToken] = useState("tgcm_7b3c_****_9d12");
  const [flood, setFlood] = useState(8);

  const copyToken = async () => {
    await navigator.clipboard.writeText(apiToken.replace("****", "A1B2"));
    setTokenCopied(true);
    setTimeout(() => setTokenCopied(false), 1200);
  };

  const regenerate = () => {
    const rand = Math.random().toString(16).slice(2, 6);
    setApiToken(`tgcm_${rand}_****_${Math.random().toString(16).slice(2, 6)}`);
  };

  return (
    <div className="px-4 md:px-8 py-6">
      <div className="mb-6">
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              Telegram Web3 Community Manager
            </h1>
            <p className="text-muted-foreground mt-1">
              Configure bot settings, automations, moderation, and Web3 gating —
              all in one place.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2">
              <Link2 className="h-4 w-4" /> Connect Telegram
            </Button>
            <Button className="gap-2">
              <Rocket className="h-4 w-4" /> New Airdrop
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-xl">Bot Status</CardTitle>
                  <CardDescription>
                    Control bot uptime and connection
                  </CardDescription>
                </div>
                <Badge
                  variant={botOnline ? "default" : "secondary"}
                  className={
                    botOnline ? "bg-accent text-accent-foreground" : ""
                  }
                >
                  {botOnline ? "Online" : "Offline"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="grid md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg border bg-muted/40">
                <div className="text-sm text-muted-foreground">Uptime</div>
                <div className="text-2xl font-bold mt-1">
                  {botOnline ? "99.99%" : "—"}
                </div>
              </div>
              <div className="p-4 rounded-lg border bg-muted/40">
                <div className="text-sm text-muted-foreground">Mode</div>
                <div className="text-2xl font-bold mt-1">Production</div>
              </div>
              <div className="p-4 rounded-lg border bg-muted/40">
                <div className="text-sm text-muted-foreground">
                  Connected Chats
                </div>
                <div className="text-2xl font-bold mt-1">18</div>
              </div>
            </CardContent>
            <CardFooter className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <ShieldCheck className="h-4 w-4 text-primary" /> Protected by
                anti-spam & verification
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="gap-2"
                  onClick={() => setBotOnline(!botOnline)}
                >
                  <Power className="h-4 w-4" /> {botOnline ? "Stop" : "Start"}
                </Button>
                <Button
                  variant="secondary"
                  className="gap-2"
                  onClick={() => {}}
                >
                  <RefreshCw className="h-4 w-4" /> Restart
                </Button>
              </div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">API Access</CardTitle>
              <CardDescription>
                Use this token to configure your bot webhook
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col md:flex-row gap-3">
                <Input readOnly value={apiToken} className="font-mono" />
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="gap-2"
                    onClick={copyToken}
                  >
                    <Copy className="h-4 w-4" />{" "}
                    {tokenCopied ? "Copied" : "Copy"}
                  </Button>
                  <Button
                    variant="secondary"
                    className="gap-2"
                    onClick={regenerate}
                  >
                    <RefreshCw className="h-4 w-4" /> Regenerate
                  </Button>
                </div>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <div className="text-sm text-muted-foreground">
                    Webhook URL
                  </div>
                  <div className="text-sm font-medium break-all">
                    https://example.app/webhook/telegram
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">
                    Permissions
                  </div>
                  <div className="text-sm font-medium">
                    messages, admins, invites
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">
                    Last rotated
                  </div>
                  <div className="text-sm font-medium">3 days ago</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="connections" className="w-full">
            <TabsList>
              <TabsTrigger value="connections">Connections</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
              <TabsTrigger value="moderation">Moderation</TabsTrigger>
              <TabsTrigger value="web3">Web3 Gating</TabsTrigger>
            </TabsList>
            <TabsContent value="connections" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">
                    Telegram Connections
                  </CardTitle>
                  <CardDescription>
                    Groups and channels managed by the bot
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between mb-3">
                    <div className="flex gap-2 w-full md:w-auto">
                      <Input placeholder="@group_or_channel" />
                      <Button className="gap-2">
                        <Link2 className="h-4 w-4" /> Add
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Users className="h-4 w-4" /> 2,316 total members
                    </div>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {[
                        {
                          name: "@web3alpha",
                          type: "Group",
                          joined: "Jan 12, 2025",
                        },
                        {
                          name: "@nft-drops",
                          type: "Channel",
                          joined: "Feb 3, 2025",
                        },
                        {
                          name: "@defi-talk",
                          type: "Group",
                          joined: "Mar 8, 2025",
                        },
                      ].map((c) => (
                        <TableRow key={c.name}>
                          <TableCell className="font-medium">
                            {c.name}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="px-2">
                              {c.type}
                            </Badge>
                          </TableCell>
                          <TableCell>{c.joined}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              Manage
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="automation" className="mt-4">
              <Card id="automation">
                <CardHeader>
                  <CardTitle className="text-xl">Automation</CardTitle>
                  <CardDescription>
                    Greetings, keyword replies, and schedules
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Welcome message
                      </div>
                      <Textarea placeholder="Welcome to the community! Verify wallet with /verify to access token-holder chats." />
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Keyword reply
                      </div>
                      <div className="flex gap-2">
                        <Input placeholder="keyword (e.g. price)" />
                        <Input placeholder="response" />
                        <Button>Add</Button>
                      </div>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-lg border bg-muted/40">
                      <div className="text-sm text-muted-foreground">
                        Rate limit
                      </div>
                      <div className="text-sm font-medium">
                        {flood} msgs/min
                      </div>
                      <input
                        type="range"
                        min={1}
                        max={30}
                        value={flood}
                        onChange={(e) => setFlood(Number(e.target.value))}
                        className="w-full mt-2"
                      />
                    </div>
                    <div className="p-4 rounded-lg border bg-muted/40">
                      <div className="text-sm text-muted-foreground">
                        Auto-replies
                      </div>
                      <div className="text-sm font-medium">6 templates</div>
                    </div>
                    <div className="p-4 rounded-lg border bg-muted/40">
                      <div className="text-sm text-muted-foreground">
                        Scheduler
                      </div>
                      <div className="text-sm font-medium">3 campaigns</div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="justify-end">
                  <Button className="gap-2">
                    <Sparkles className="h-4 w-4" /> Save automation
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="moderation" className="mt-4">
              <Card id="moderation">
                <CardHeader>
                  <CardTitle className="text-xl">Moderation</CardTitle>
                  <CardDescription>
                    Anti-spam and verification checks
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>Block suspicious links</span>
                        <Switch defaultChecked />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Prevents phishing domains and repeated links
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>Flood control</span>
                        <Switch defaultChecked />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Auto-mute users who exceed message rate
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span>New member cooldown</span>
                        <Switch />
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Restrict new users for the first 5 minutes
                      </p>
                    </div>
                  </div>
                  <Separator />
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Verification method
                      </div>
                      <Select defaultValue="wallet">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="captcha">Captcha</SelectItem>
                          <SelectItem value="wallet">
                            Wallet signature
                          </SelectItem>
                          <SelectItem value="token">Token balance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Mute duration
                      </div>
                      <Select defaultValue="10">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">5 min</SelectItem>
                          <SelectItem value="10">10 min</SelectItem>
                          <SelectItem value="30">30 min</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button variant="secondary" className="w-full gap-2">
                        <Shield className="h-4 w-4" /> Apply rules
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="web3" className="mt-4">
              <Card id="web3">
                <CardHeader>
                  <CardTitle className="text-xl">Web3 Gating</CardTitle>
                  <CardDescription>
                    Require wallet verification or token/NFT ownership
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <div className="text-sm font-medium">
                        Require wallet verification
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">Chain</div>
                      <Select defaultValue="eth">
                        <SelectTrigger>
                          <SelectValue placeholder="Select chain" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="eth">Ethereum</SelectItem>
                          <SelectItem value="sol">Solana</SelectItem>
                          <SelectItem value="base">Base</SelectItem>
                          <SelectItem value="polygon">Polygon</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Min token balance
                      </div>
                      <Input placeholder="e.g. 100" type="number" />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Token/NFT contract
                      </div>
                      <Input placeholder="0x... or collection slug" />
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">
                        Role on pass
                      </div>
                      <Select defaultValue="member">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="member">Member</SelectItem>
                          <SelectItem value="og">OG Holder</SelectItem>
                          <SelectItem value="mod">Moderator</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="justify-end gap-2">
                  <Button variant="outline" className="gap-2">
                    <Wallet className="h-4 w-4" /> Test gate
                  </Button>
                  <Button className="gap-2">
                    <LockKeyhole className="h-4 w-4" /> Save gating
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Overview</CardTitle>
              <CardDescription>Today</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-lg border bg-muted/40">
                  <div className="text-xs text-muted-foreground">
                    New members
                  </div>
                  <div className="text-xl font-bold">128</div>
                </div>
                <div className="p-4 rounded-lg border bg-muted/40">
                  <div className="text-xs text-muted-foreground">
                    Active users
                  </div>
                  <div className="text-xl font-bold">742</div>
                </div>
                <div className="p-4 rounded-lg border bg-muted/40">
                  <div className="text-xs text-muted-foreground">
                    Wallet verifications
                  </div>
                  <div className="text-xl font-bold">316</div>
                </div>
                <div className="p-4 rounded-lg border bg-muted/40">
                  <div className="text-xs text-muted-foreground">
                    Blocked spam
                  </div>
                  <div className="text-xl font-bold">1,204</div>
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">
                  Airdrop progress
                </div>
                <Progress value={62} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Recent activity</CardTitle>
              <CardDescription>System events</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <ActivityItem
                icon={<Shield className="h-4 w-4 text-primary" />}
                label="Anti-spam muted @bad_actor for flood"
                time="2m ago"
              />
              <ActivityItem
                icon={<CheckCircle2 className="h-4 w-4 text-accent" />}
                label="Wallet verified for 0x12...a9F2"
                time="8m ago"
              />
              <ActivityItem
                icon={<Rocket className="h-4 w-4 text-primary" />}
                label={'Scheduled airdrop campaign "OG Wave"'}
                time="21m ago"
              />
              <ActivityItem
                icon={<BarChart3 className="h-4 w-4 text-primary" />}
                label="Daily report generated"
                time="1h ago"
              />
              <ActivityItem
                icon={<Users className="h-4 w-4 text-primary" />}
                label="@nft-drops reached 10k members"
                time="3h ago"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Shortcuts</CardTitle>
              <CardDescription>Quick actions</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="justify-start gap-2">
                <Power className="h-4 w-4" /> Toggle bot
              </Button>
              <Button variant="outline" className="justify-start gap-2">
                <RefreshCw className="h-4 w-4" /> Rotate token
              </Button>
              <Button variant="outline" className="justify-start gap-2">
                <Link2 className="h-4 w-4" /> Add connection
              </Button>
              <Button variant="outline" className="justify-start gap-2">
                <Activity className="h-4 w-4" /> View logs
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ActivityItem({
  icon,
  label,
  time,
}: {
  icon: React.ReactNode;
  label: string;
  time: string;
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="h-8 w-8 rounded-md bg-secondary grid place-items-center">
        {icon}
      </div>
      <div className="flex-1">
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{time}</div>
      </div>
    </div>
  );
}
